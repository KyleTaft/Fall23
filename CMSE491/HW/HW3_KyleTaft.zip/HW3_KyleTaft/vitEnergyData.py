# Load modules
print("Loading modules...")

import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import tensorflow_addons as tfa
# %% [markdown]
# ## Prepare the data

# %%
# num_classes = 100
# input_shape = (32, 32, 3)

# (x_train, y_train), (x_test, y_test) = keras.datasets.cifar100.load_data()

# print(f"x_train shape: {x_train.shape} - y_train shape: {y_train.shape}")
# print(f"x_test shape: {x_test.shape} - y_test shape: {y_test.shape}")


# %% [markdown]
# ## Configure the hyperparameters

# %%
input_shape = (512, 512, 1)

print("Reading in data...")
# Read in data
x_train_singles = np.load("/mnt/home/taftkyle/indiv_data/singles/raw_single_train.npy")
# y_train_singles = np.load("/mnt/home/taftkyle/indiv_data/singles/single_train_label.npy")
# x_test_singles = np.load("/mnt/home/taftkyle/indiv_data/singles/raw_single_test.npy")[0:100]
# y_test_singles = np.load("/mnt/home/taftkyle/indiv_data/singles/single_test_label.npy")[0:100]

# new_y_train_singles = []
# for i in range(len(y_train_singles)):
#     cord = np.unravel_index(np.argmax(y_train_singles[i], axis=None), y_train_singles[i].shape)[0:2]
#     cord = np.array([20*cord[1], 20*(511-cord[0])]) # convert to energy
#     new_y_train_singles.append(np.pad(cord, (0, 2), 'constant', constant_values=(-1,-1))) # add padding of -1 energies (unphysical)

# new_y_test_singles = []
# for i in range(len(y_test_singles)):
#     cord = np.unravel_index(np.argmax(y_test_singles[i], axis=None), y_test_singles[i].shape)[0:2]
#     cord = np.array([20*cord[1], 20*(511-cord[0])]) # convert to energy
#     new_y_test_singles.append(np.pad(cord, (0, 2), 'constant', constant_values=(-1,-1))) # add padding of -1 energies (unphysical)

# y_train_singles = np.array(new_y_train_singles)
# y_test_singles = np.array(new_y_test_singles)

x_train_double = np.load("/mnt/home/taftkyle/indiv_data/doubles/raw_double_train.npy")
# y_train_double = np.load("/mnt/home/taftkyle/indiv_data/doubles/double_train_label.npy")
# x_test_double = np.load("/mnt/home/taftkyle/indiv_data/doubles/raw_double_test.npy")[0:100]
# y_test_double = np.load("/mnt/home/taftkyle/indiv_data/doubles/double_test_label.npy")[0:100]

# new_y_train_double = []
# for i in range(len(y_train_double)):
#     cord = np.unravel_index(np.argmax(y_train_double[i], axis=None), y_train_double[i].shape)[0:2]
#     # find the second max
#     y_train_double[i][cord[0], cord[1]] = 0
#     cord2 = np.unravel_index(np.argmax(y_train_double[i], axis=None), y_train_double[i].shape)[0:2]
#     new_y_train_double.append([20*cord[1], 20*(511-cord[0]), 20*cord2[1], 20*(511-cord2[0])])

# new_y_test_double = []
# for i in range(len(y_test_double)):
#     cord = np.unravel_index(np.argmax(y_test_double[i], axis=None), y_test_double[i].shape)[0:2]
#     # find the second max
#     y_test_double[i][cord[0], cord[1]] = 0
#     cord2 = np.unravel_index(np.argmax(y_test_double[i], axis=None), y_test_double[i].shape)[0:2]
#     new_y_test_double.append([20*cord[1], 20*(511-cord[0]), 20*cord2[1], 20*(511-cord2[0])])

# y_train_double = np.array(new_y_train_double)
# y_test_double = np.array(new_y_test_double)

# %%
#Combine the data
x_train = np.concatenate((x_train_singles, x_train_double))
y_train = np.load("y_train.npy")
# y_train = np.concatenate((y_train_singles, y_train_double))
# x_test = np.concatenate((x_test_singles, x_test_double))
# y_test = np.concatenate((y_test_singles, y_test_double))

print("x_train shape:", x_train.shape)
print("y_train shape:", y_train.shape)
# print("x_test shape:", x_test.shape)
# print("y_test shape:", y_test.shape)

# np.save("y_train.npy", y_train)

#Shuffle data
indices = np.arange(x_train.shape[0])
np.random.shuffle(indices)
x_train = x_train[indices]
y_train = y_train[indices]




# %%
learning_rate = 0.001
weight_decay = 0.0001
batch_size = 128
num_epochs = 100
image_size = 512  # We'll resize input images to this size
patch_size = 32  # Size of the patches to be extract from the input images
num_patches = (image_size // patch_size) ** 2
projection_dim = 64
num_heads = 4
transformer_units = [
    projection_dim * 2,
    projection_dim,
]  # Size of the transformer layers
transformer_layers = 8
mlp_head_units = [2048, 1024]  # Size of the dense layers of the final classifier


# %% [markdown]
# ## Use data augmentation

# %%
data_augmentation = keras.Sequential(
    [
        layers.Normalization(),
        layers.Resizing(image_size, image_size),
        # layers.RandomFlip("horizontal"),
        # layers.RandomRotation(factor=0.02),
        # layers.RandomZoom(
        #     height_factor=0.2, width_factor=0.2
        # ),
    ],
    name="data_augmentation",
)
# Compute the mean and the variance of the training data for normalization.
data_augmentation.layers[0].adapt(x_train)


# %% [markdown]
# ## Implement multilayer perceptron (MLP)

# %%

def mlp(x, hidden_units, dropout_rate):
    for units in hidden_units:
        x = layers.Dense(units, activation=tf.nn.gelu)(x)
        x = layers.Dropout(dropout_rate)(x)
    return x


# %% [markdown]
# ## Implement patch creation as a layer

# %%

class Patches(layers.Layer):
    def __init__(self, patch_size):
        super().__init__()
        self.patch_size = patch_size

    def call(self, images):
        batch_size = tf.shape(images)[0]
        patches = tf.image.extract_patches(
            images=images,
            sizes=[1, self.patch_size, self.patch_size, 1],
            strides=[1, self.patch_size, self.patch_size, 1],
            rates=[1, 1, 1, 1],
            padding="VALID",
        )
        patch_dims = patches.shape[-1]
        patches = tf.reshape(patches, [batch_size, -1, patch_dims])
        return patches


# %% [markdown]
# Let's display patches for a sample image

# %%
import matplotlib.pyplot as plt

plt.figure(figsize=(4, 4))
image = x_train[np.random.choice(range(x_train.shape[0]))]
plt.imshow(image.astype("uint8"))
plt.axis("off")

resized_image = tf.image.resize(
    tf.convert_to_tensor([image]), size=(image_size, image_size)
)
print("Patch size:", patch_size)
print("Image size:", image_size)
print("Patches per image:", num_patches)
print("Resized", resized_image.shape)
patches = Patches(patch_size)(resized_image)
print(f"Image size: {image_size} X {image_size}")
print(f"Patch size: {patch_size} X {patch_size}")
print(f"Patches per image: {patches.shape[1]}")
print(f"Elements per patch: {patches.shape[-1]}")

# n = int(np.sqrt(patches.shape[1]))
# plt.figure(figsize=(4, 4))
# for i, patch in enumerate(patches[0]):
#     ax = plt.subplot(n, n, i + 1)
#     patch_img = tf.reshape(patch, (patch_size, patch_size, 1))
#     plt.imshow(patch_img.numpy().astype("uint8"))
#     plt.axis("off")

# %% [markdown]
# ## Implement the patch encoding layer
# 
# The `PatchEncoder` layer will linearly transform a patch by projecting it into a
# vector of size `projection_dim`. In addition, it adds a learnable position
# embedding to the projected vector.

# %%

class PatchEncoder(layers.Layer):
    def __init__(self, num_patches, projection_dim):
        super().__init__()
        self.num_patches = num_patches
        self.projection = layers.Dense(units=projection_dim)
        self.position_embedding = layers.Embedding(
            input_dim=num_patches, output_dim=projection_dim
        )

    def call(self, patch):
        positions = tf.range(start=0, limit=self.num_patches, delta=1)
        encoded = self.projection(patch) + self.position_embedding(positions)
        return encoded


# %% [markdown]
# ## Build the ViT model
# 
# The ViT model consists of multiple Transformer blocks,
# which use the `layers.MultiHeadAttention` layer as a self-attention mechanism
# applied to the sequence of patches. The Transformer blocks produce a
# `[batch_size, num_patches, projection_dim]` tensor, which is processed via an
# classifier head with softmax to produce the final class probabilities output.
# 
# Unlike the technique described in the [paper](https://arxiv.org/abs/2010.11929),
# which prepends a learnable embedding to the sequence of encoded patches to serve
# as the image representation, all the outputs of the final Transformer block are
# reshaped with `layers.Flatten()` and used as the image
# representation input to the classifier head.
# Note that the `layers.GlobalAveragePooling1D` layer
# could also be used instead to aggregate the outputs of the Transformer block,
# especially when the number of patches and the projection dimensions are large.

# %%

def create_vit_classifier():
    print(input_shape)
    inputs = layers.Input(shape=input_shape)
    # Augment data.
    augmented = data_augmentation(inputs)
    # Create patches.
    patches = Patches(patch_size)(augmented)
    # Encode patches.
    encoded_patches = PatchEncoder(num_patches, projection_dim)(patches)

    # Create multiple layers of the Transformer block.
    for _ in range(transformer_layers):
        # Layer normalization 1.
        x1 = layers.LayerNormalization(epsilon=1e-6)(encoded_patches)
        # Create a multi-head attention layer.
        attention_output = layers.MultiHeadAttention(
            num_heads=num_heads, key_dim=projection_dim, dropout=0.1
        )(x1, x1)
        # Skip connection 1.
        x2 = layers.Add()([attention_output, encoded_patches])
        # Layer normalization 2.
        x3 = layers.LayerNormalization(epsilon=1e-6)(x2)
        # MLP.
        x3 = mlp(x3, hidden_units=transformer_units, dropout_rate=0.1)
        # Skip connection 2.
        encoded_patches = layers.Add()([x3, x2])

    # Create a [batch_size, projection_dim] tensor.
    representation = layers.LayerNormalization(epsilon=1e-6)(encoded_patches)
    representation = layers.Flatten()(representation)
    representation = layers.Dropout(0.5)(representation)
    # Add MLP.
    features = mlp(representation, hidden_units=mlp_head_units, dropout_rate=0.5)
    # # Classify outputs.
    # logits = layers.Dense(num_classes)(features)

    # Output layers for peak localization and intensity prediction
    # Modify these output layers based on your specific task
    #peak_localization = layers.Dense(2, activation='linear')(features)  # (x, y) coordinates of peak centers

    peak_localization = layers.Dense(4, activation='linear')(features)  # (x, y) coordinates of peak centers
    #peak_intensity = layers.Dense(num_classes, activation='softmax')(features)  # Intensity prediction

    # Create the custom ViT model
    model = keras.Model(inputs=inputs, outputs=peak_localization)

    return model

    # # Create the Keras model.
    # model = keras.Model(inputs=inputs, outputs=logits)
    # return model


# %% [markdown]
# ## Compile, train, and evaluate the mode

# %%

def run_experiment(model):
    optimizer = tfa.optimizers.AdamW(
        learning_rate=learning_rate, weight_decay=weight_decay
    )

    model.compile(
        optimizer=optimizer,
        # loss=keras.losses.SparseCategoricalCrossentropy(from_logits=True),
        loss=keras.losses.MeanSquaredError(),
        # metrics=[
        #     keras.metrics.SparseCategoricalAccuracy(name="accuracy"),
        #     keras.metrics.SparseTopKCategoricalAccuracy(5, name="top-5-accuracy"),
        # ],
        metrics=[
            keras.metrics.MeanSquaredError(name="mse"),
            keras.metrics.MeanAbsoluteError(name="mae"),
        ],
    )

    checkpoint_filepath = "tmp/checkpoint/vit_checkpoint"
    checkpoint_callback = keras.callbacks.ModelCheckpoint(
        checkpoint_filepath,
        monitor="val_mae",
        save_best_only=True,
        save_weights_only=True,
    )

    history = model.fit(
        x=x_train,
        y=y_train,
        batch_size=batch_size,
        epochs=num_epochs,
        validation_split=0.1,
        callbacks=[checkpoint_callback],
    )

    # model.load_weights(checkpoint_filepath)
    # _, accuracy, top_5_accuracy = model.evaluate(x_test, y_test)
    # print(f"Test accuracy: {round(accuracy * 100, 2)}%")
    # print(f"Test top 5 accuracy: {round(top_5_accuracy * 100, 2)}%")
    model.save("vitModelEnergyData")

    return history


vit_classifier = create_vit_classifier()
history = run_experiment(vit_classifier)

plt.figure()
plt.plot(history.history['loss'], label = "training loss")
plt.plot(history.history['val_loss'], label = "validation loss")
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.yscale('log')
plt.legend()
plt.savefig('trainlossVIT.png')


# # %%
# def matrix_to_coords(array):
#     xys = []
#     values = []
#     for i in range(array.shape[0]):
#         for j in range(array.shape[1]):
#             xys.append((20*j,20*(511-i)))
#             #xys.append((j,(511-i)))
#             values.append(array[i,j])
#     return np.asarray(xys), np.asarray(values)

# # %%
# # singles_train = np.load("/mnt/home/taftkyle/indiv_data/singles/raw_single_train.npy")
# # doubles_train = np.load("/mnt/home/taftkyle/indiv_data/doubles/raw_double_train.npy")
# #sample = singles_train[404]
# sample = doubles_train[404]
# data = sample.copy()
# #change to float
# data = data.astype(float)
# print(data.shape)
# print("Total Counts:", np.sum(data))
# print("Maxiumum Point:", np.unravel_index(np.argmax(data, axis=None), data.shape))
# print("Second Maxiumum Point:", np.unravel_index(np.argsort(data, axis=None)[-2], data.shape))


# # data = data[490:, 0:10, :] #slice to get rid of empty space

# #replace all values less than 0.001 with nan in order to appear white on graph
# data[data == 0] = np.nan

# plt.figure(figsize=(10,10))
# points, vals = matrix_to_coords(data)
# plt.scatter(points[:,0],points[:,1], marker='s', c=vals, cmap='viridis', label="High Value Pixels", s=1)
# cbar = plt.colorbar()
# plt.xlim(0,10000)
# plt.ylim(0,10000)

# # %%
# # make predictions
# predictions = vit_classifier.predict(np.asarray([sample]))
# print(predictions)


